#include <iostream>
using namespace std;
main() {
system("color 53"); 
cout << "                                     " <<endl;
cout << "               ____________________                                " <<endl;
cout << "              //         |        \\               " <<endl;
cout << "             //          |         \\              " <<endl;
cout << "           //------------------------\\                                   " <<endl;
cout << "    -----------------------------------------                           " <<endl;
cout << "  //  __________                 __________  \\           " <<endl;
cout << " //__|          |               |          |__\\     " <<endl;
cout << "     |          |_______________|          |            " <<endl;
cout << "     |          |               |          |        " <<endl;
cout << "     |__________|               |__________|      " <<endl;
cout << "                                     " <<endl;
cout << "                                     " <<endl;
cout << "                                     " <<endl;
}