#include <iostream>
using namespace std;
main() {
system ("color 46")
cout << "##########     ####     ########## ######         " <<endl;
cout << "#########     ##  ##    ########## ##    ##       " <<endl;
cout << "      ##     ##    ##       ##     ##     ##      " <<endl;
cout << "     ##     ##      ##      ##     ##      ##       " <<endl;
cout << "    ##     ############     ##     ##       ##      " <<endl;
cout << "   ##      ############     ##     ##      ##       " <<endl;
cout << "  ##       ##        ##     ##     ##     ##       " <<endl;
cout << " ######### ##        ## ########## ##    ##         " <<endl;
cout << "########## ##        ## ########## ######          " <<endl;
cout << "" <<endl;
}